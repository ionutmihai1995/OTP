﻿namespace OTP.Service.Config
{
    public class OTPGeneratorConfiguration
    {
        public string AllowedChars { get; set; }
        public int Length { get; set; }
    }
}
