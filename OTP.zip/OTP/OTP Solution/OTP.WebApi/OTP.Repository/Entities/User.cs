﻿namespace OTP.Repository.Entities
{
    public class User : IdentifiableEntity
    {
        public string UserID { get; set; }
    }
}
