export class ValidityResult{
    userId : string;
    secretKeyGuid : string;
    generatedOTP : string;
    expiredDate: Date
}